// 'brand_id', 'license_plate','name','price_per_day',

let listaVeiculos = [
    {
        brand: "Fiat",
        name: "Palio",
        price_per_day: 60,
        license_plate: "AAA-0000"
    },
    {
        brand: "Renault",
        name: "Sandero",
        price_per_day: 65,
        license_plate: "BBB-0000"
    }
]


let usuario = {
    name: "Maria Silva",
    id: 1,
}

async function buscarVeiculos() {
    let resposta = await new Promise(resolve => (
        setTimeout(() => {
            resolve(listaVeiculos)
        }, 2000)
    ))

    let nomeUsuario = document.querySelector("#nome-usuario")
    let lista = document.querySelector('#lista-veiculos')

    nomeUsuario.innerText = `Olá, ${usuario.name}`
    
    resposta.forEach((veiculo) => {
        let itemVeiculo = document.createElement('li')
        let marca = document.createElement('p')
        let modelo = document.createElement('p')
        let placa = document.createElement('p')
        let preco = document.createElement('p')
        
        marca.innerText = veiculo.brand;
        modelo.innerText = veiculo.name;
        placa.innerText = veiculo.license_plate;
        preco.innerText = Intl.NumberFormat("pt-BR", {
            style:'currency',
            currency: 'BRL'
        }).format(veiculo.price_per_day)

        itemVeiculo.append(marca, modelo, placa, preco)
        lista.append(itemVeiculo)
    })
    
}

document.addEventListener('DOMContentLoaded', buscarVeiculos())