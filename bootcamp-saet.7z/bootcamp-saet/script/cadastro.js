let form = document.querySelector('form')
let mostraSenha = false;

function alternaSenha() {
    let abertoList = document.querySelectorAll(".olho-aberto")
    let fechadoList = document.querySelectorAll(".olho-fechado")
    let campoSenha = document.querySelector('input[name="senha"]')
    let campoConfirma = document.querySelector('input[name="confirma"]')

    // () => {}
    if(mostraSenha) {
        abertoList.forEach((aberto) => {
            aberto.style.display = 'none';
        })
        fechadoList.forEach((fechado) => {
            fechado.style.display = 'block';
        })
        campoSenha.type = "password"
        campoConfirma.type = "password"
    }else {
        abertoList.forEach((aberto) => {
            aberto.style.display = 'block';
        })
        fechadoList.forEach((fechado) => {
            fechado.style.display = 'none';
        })
        campoSenha.type = "text"
        campoConfirma.type = "text"
    }

    mostraSenha = !mostraSenha;
}

function salvarCadastro(evento) {
    evento.preventDefault()
    let campoNome = document.querySelector("#nome")
    let campoEmail = document.querySelector("#email")
    let campoSenha = document.querySelector('input[name="senha"]')
    let campoConfirma = document.querySelector('input[name="confirma"]')
    let erros = [];

    let padrao = /^[a-zA-Z0-9._+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/
    let dados = {
        nome: campoNome.value,
        email: campoEmail.value,
        senha: campoSenha.value,
        confirma: campoConfirma.value,
    }

    if(!padrao.test(dados.email)){
        erros.push("Email inválido");
    }

    if(dados.senha !== dados.confirma){
        erros.push("A senha deve ser igual a confirmação de senha")
    }

    if(dados.senha.length < 8){
        erros.push('Senha fraca! Por favor, altere.')
    }

    if(erros.length > 0){
        erros.forEach((erro) => {
            Swal.fire({
                title: erro,
                icon: "error",
                toast: true,
                showConfirmButton: false,
                timer: 1500,
                position: "bottom",
            })
        })
        return
    }

    Swal.fire({
        title: "Cadastro feito com sucesso!",
        icon: "success",
        toast: true,
        showConfirmButton: false,
        timer: 1500,
        position: "bottom",
    })
    console.log(dados)
}

form.addEventListener('submit', (e) => salvarCadastro(e))